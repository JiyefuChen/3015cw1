#include "scenebasic_uniform.h"

#include <cstdio>
#include <cstdlib>

#include <string>
using std::string;

#include <iostream>
using std::cerr;
using std::endl;

#include "helper/glutils.h"

using glm::vec3;

SceneBasic_Uniform ::SceneBasic_Uniform () {}

void SceneBasic_Uniform ::initScene() {
    glEnable(GL_DEPTH_TEST);

    compile();
    CreateObjects();

    // camera = Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), -60.0f, 0.0f, 5.0f, 0.5f);
    camera = Camera(glm::vec3(0.0f, -1.0f, 15.0f), glm::vec3(0.0f, 1.0f, 0.0f), 180.0f, 90.0f, 5.0f, 0.5f);

    brickTexture = Texture("media/Textures/brick.png");
    brickTexture.LoadTextureA();
    dirtTexture = Texture("media/Textures/dirt.png");
    dirtTexture.LoadTextureA();
    plainTexture = Texture("media/Textures/plain.png");
    plainTexture.LoadTextureA();

    shinyObjMaterial = ObjMaterial(4.0f, 256);
    dullObjMaterial = ObjMaterial(0.3f, 4);

    xwing = ObjModel();
    xwing.LoadObjModel("media/Models/ZhuangPei.obj");

    blackhawk = ObjModel();
    blackhawk.LoadObjModelCar("media/Models/carMin.obj");

    lightControlBox1 = ObjModel();
    lightControlBox1.LoadObjModelLightControl1("media/Models/controlbox.obj");

    lightControlBox2 = ObjModel();
    lightControlBox2.LoadObjModelLightControl2("media/Models/controlbox.obj");

    pBlue = ObjModel();
    pBlue.LoadObjModelCar("media/Models/PBlue.obj");

    pYellow = ObjModel();
    pYellow.LoadObjModelLightControl2("media/Models/PYellow.obj");

    mainLight = DirectionalLight(2048, 2048, 1.0f, 1.0f, 1.0f, 0.1f, 0.9f, 0.0f, -15.0f, -10.0f);

    pointLights[1] =
        PointLight(1024, 1024, 0.1f, 100.0f, 1.0f, 1.0f, 1.0f, 1.2f, 1.4f, 2.0f, 2.0f, 0.0f, 0.3f, 0.01f, 0.01f);

    std::vector<std::string> skyboxFaces;
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_rt.tga");
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_lf.tga");
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_up.tga");
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_dn.tga");
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_bk.tga");
    skyboxFaces.push_back("media/Textures/Skybox/devils-tooth_ft.tga");

    skybox = Skybox(skyboxFaces);

    projection = glm::perspective(glm::radians(60.0f), (GLfloat)width / height, 0.1f, 100.0f);
}

void SceneBasic_Uniform ::compile() {
    try {
        directionalShadowShader.compileShader("shader/directional_shadow_map.vert");
        directionalShadowShader.compileShader("shader/directional_shadow_map.frag");
        directionalShadowShader.link();

        omniShadowShader.compileShader("shader/omni_directional_shadow_map.vert");
        omniShadowShader.compileShader("shader/omni_directional_shadow_map.geom");
        omniShadowShader.compileShader("shader/omni_directional_shadow_map.frag");
        omniShadowShader.link();

        defaultShader.compileShader("shader/shader.vert");
        defaultShader.compileShader("shader/shader.frag");
        defaultShader.link();
    } catch (GLSLProgramException &e) {
        cerr << e.what() << endl;
        exit(EXIT_FAILURE);
    }
}

void SceneBasic_Uniform ::update(float t) {
    GLfloat now = (GLfloat)glfwGetTime();  // SDL_GetPerformanceCounter();
    deltaTime = now - lastTime;            // (now - lastTime)*1000/SDL_GetPerformanceFrequency();
    lastTime = now;

    camera.keyControl(keys, deltaTime);
    GLfloat theChangex = xChange, theChangey = yChange;
    xChange = 0.0f;
    yChange = 0.0f;
    camera.mouseControl(theChangex, theChangey);

    if (keys[GLFW_KEY_O]) {
        lightcontrolFlag1 = true;
        lightcontrolFlag2 = false;
        movingForward = true;
    }
    if (keys[GLFW_KEY_P]) {
        lightcontrolFlag1 = false;
        lightcontrolFlag2 = true;
        movingForward = false;
    }

        // camera.keyControl(mainWindow.getsKeys(), deltaTime);
        // camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

        // if (mainWindow.getsKeys()[GLFW_KEY_O]) {
        //     lightcontrolFlag1 = true;
        //     lightcontrolFlag2 = false;
        //     movingForward = true;
        // }
        // if (mainWindow.getsKeys()[GLFW_KEY_P]) {
        //     lightcontrolFlag1 = false;
        //     lightcontrolFlag2 = true;
        //     movingForward = false;
        // }
    }

void SceneBasic_Uniform ::RenderScene() {
    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(0.0f, -2.0f, 0.0f));
    model = glm::scale(model, glm::vec3(2.0f, 1.0f, 1.0f));

    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);

    dirtTexture.UseTexture();

    shinyObjMaterial.UseObjMaterial(defaultShader.getUniformLocation("material.specularIntensity"),
                                    defaultShader.getUniformLocation("material.shininess"));

    meshList[2]->RenderObjMesh();

    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(0.0f, -2.0f, 10.0f));

    model = glm::scale(model, glm::vec3(0.006f, 0.006f, 0.006f));
    
    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);

    xwing.RenderObjModel();

    if (lightcontrolFlag1) {
        if (carPosition < -1.0f) carPosition = -0.99;

        if (carPosition > -1.0f && carPosition < 0.2f) {
            carPosition += carSpeed;
        }
    } else if (lightcontrolFlag2) {
        if (carPosition > 0.2f) carPosition = 0.19;
        if (carPosition > -1.0f && carPosition < 0.2f) {
            carPosition -= carSpeed;
        }
    }

    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(0.00f, 0.7f - 3.55 + 1.55, 22.0f + carPosition - 11.13));
    model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    model = glm::scale(model, glm::vec3(0.0063f, 0.0063f, 0.0063f));

    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);

   // glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, glm::value_ptr(model));
    // shinyObjMaterial.UseObjMaterial(uniformSpecularIntensity, uniformShininess);

    blackhawk.RenderObjModel();

    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(-0.825f, -1.35f, 11.45f));
    model = glm::scale(model, glm::vec3(0.006f, 0.09f, 0.005f));
    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);

    if (lightcontrolFlag1) {
        lightControlBox1.RenderObjModel();
    } else if (lightcontrolFlag2) {
        lightControlBox2.RenderObjModel();
    } else {
        lightControlBox2.RenderObjModel();
    }

    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(0.02f, -2.00f, 10.035f));
    model = glm::scale(model, glm::vec3(0.0061f, 0.0061f, 0.0061f));
    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);
    // shinyObjMaterial.UseObjMaterial(uniformSpecularIntensity, uniformShininess);
    pBlue.RenderObjModel();

    model = glm::mat4(1.0);
    model = glm::translate(model, glm::vec3(-0.01f, -2.03f, 9.98f));
    model = glm::scale(model, glm::vec3(0.0062f, 0.0062f, 0.0062f));
    glUniformMatrix4fv(uniformObjModel, 1, GL_FALSE, (float *)&model);
    // shinyObjMaterial.UseObjMaterial(uniformSpecularIntensity, uniformShininess);
    pYellow.RenderObjModel();
    blackhawkAngle += 0.1;
}

void SceneBasic_Uniform ::DirectionalShadowMapPass(DirectionalLight *light) {
    directionalShadowShader.use();

    glViewport(0, 0, light->GetShadowMap()->GetShadowWidth(), light->GetShadowMap()->GetShadowHeight());

    light->GetShadowMap()->Write();
    glClear(GL_DEPTH_BUFFER_BIT);

    uniformObjModel = directionalShadowShader.getUniformLocation("model");
    directionalShadowShader.setUniform("directionalLightTransform", light->CalculateLightTransform());

    RenderScene();

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void SceneBasic_Uniform ::SpecialShadowMapPass(PointLight *light) {
    glViewport(0, 0, light->GetShadowMap()->GetShadowWidth(), light->GetShadowMap()->GetShadowHeight());

    omniShadowShader.use();
    uniformObjModel = omniShadowShader.getUniformLocation("model");
    // uniformSpecialLightPos = omniShadowShader.GetSpecialLightPosLocation();
    // uniformFarPlane = omniShadowShader.GetFarPlaneLocation();

    light->GetShadowMap()->Write();

    glClear(GL_DEPTH_BUFFER_BIT);

    omniShadowShader.setUniform("lightPos", light->GetPosition());
    omniShadowShader.setUniform("farPlane", light->GetFarPlane());

    auto mat = light->CalculateLightTransform();
    std::string str;
    for (int i = 0; i < 6; ++i) {
        str = "lightMatrices[" + std::to_string(i) + "]";
        omniShadowShader.setUniform(str.c_str(), mat[i]);
    }
    RenderScene();

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void SceneBasic_Uniform ::RenderPass(glm::mat4 projectionMatrix, glm::mat4 viewMatrix) {
    glViewport(0, 0, 1280, 768);  // 1280, 1024 or 1024, 768

    // Clear the window
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    skybox.DrawSkybox(viewMatrix, projectionMatrix);

    defaultShader.use();

    uniformObjModel = defaultShader.getUniformLocation("model");

    defaultShader.setUniform("projection", projectionMatrix);
    defaultShader.setUniform("view", viewMatrix);
    defaultShader.setUniform("eyePosition", camera.getCameraPosition());

    // defaultShader.setUniform("eyePosition", camera.getCameraPosition());

    mainLight.UseLight(defaultShader.getUniformLocation("directionalLight.base.ambientIntensity"),
                       defaultShader.getUniformLocation("directionalLight.base.colour"),
                       defaultShader.getUniformLocation("directionalLight.base.diffuseIntensity"),
                       defaultShader.getUniformLocation("directionalLight.direction"));

    defaultShader.setUniform("pointLightCount", pointLightCount);
    auto textureUnit = 3;
    for (int i = 0; i < pointLightCount; ++i) {
        std::string str = "pointLights[" + std::to_string(i) + "].";
        auto s0 = str + "base.ambientIntensity";
        auto s1 = str + "base.colour";
        auto s2 = str + "base.diffuseIntensity";
        auto s3 = str + "position";
        auto s4 = str + "constant";
        auto s5 = str + "linear";
        auto s6 = str + "exponent";
        pointLights[i].UseLight(
            defaultShader.getUniformLocation(s0.c_str()), defaultShader.getUniformLocation(s1.c_str()),
            defaultShader.getUniformLocation(s2.c_str()), defaultShader.getUniformLocation(s3.c_str()),
            defaultShader.getUniformLocation(s4.c_str()), defaultShader.getUniformLocation(s5.c_str()),
            defaultShader.getUniformLocation(s6.c_str()));
        pointLights[i].GetShadowMap()->Read(GL_TEXTURE0 + textureUnit + i);
        str = "omniShadowMaps[" + std::to_string(i) + "].";
        auto s7 = str + "shadowMap";
        auto s8 = str + "farPlane";
        defaultShader.setUniform(s7.c_str(), textureUnit + i);
        defaultShader.setUniform(s8.c_str(), pointLights[i].GetFarPlane());
    }

    // defaultShader.SetPointLights(pointLights, pointLightCount, 3, 0);

    defaultShader.setUniform("directionalLightTransform", mainLight.CalculateLightTransform());
    // defaultShader.SetDirectionalLightTransform(&mainLight.CalculateLightTransform());

    mainLight.GetShadowMap()->Read(GL_TEXTURE2);

    defaultShader.setUniform("theTexture", 1);
    defaultShader.setUniform("directionalShadowMap", 2);
    // defaultShader.SetDirectionalShadowMap(2);

    glm::vec3 lowerLight = camera.getCameraPosition();
    lowerLight.y -= 0.3f;

    RenderScene();
}
void SceneBasic_Uniform ::calcAverageNormals(unsigned int *indices, unsigned int indiceCount, GLfloat *vertices,
                                 unsigned int verticeCount, unsigned int vLength, unsigned int normalOffset) {
    for (size_t i = 0; i < indiceCount; i += 3) {
        unsigned int in0 = indices[i] * vLength;
        unsigned int in1 = indices[i + 1] * vLength;
        unsigned int in2 = indices[i + 2] * vLength;
        glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1],
                     vertices[in1 + 2] - vertices[in0 + 2]);
        glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1],
                     vertices[in2 + 2] - vertices[in0 + 2]);
        glm::vec3 normal = glm::cross(v1, v2);
        normal = glm::normalize(normal);

        in0 += normalOffset;
        in1 += normalOffset;
        in2 += normalOffset;
        vertices[in0] += normal.x;
        vertices[in0 + 1] += normal.y;
        vertices[in0 + 2] += normal.z;
        vertices[in1] += normal.x;
        vertices[in1 + 1] += normal.y;
        vertices[in1 + 2] += normal.z;
        vertices[in2] += normal.x;
        vertices[in2 + 1] += normal.y;
        vertices[in2 + 2] += normal.z;
    }

    for (size_t i = 0; i < verticeCount / vLength; i++) {
        unsigned int nOffset = i * vLength + normalOffset;
        glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
        vec = glm::normalize(vec);
        vertices[nOffset] = vec.x;
        vertices[nOffset + 1] = vec.y;
        vertices[nOffset + 2] = vec.z;
    }
}
void SceneBasic_Uniform ::CreateObjects() {
    unsigned int indices[] = {0, 3, 1, 1, 3, 2, 2, 3, 0, 0, 1, 2};

    GLfloat vertices[] = {//	x      y      z			u	  v			nx	  ny    nz
                          -1.0f, -1.0f, -0.6f, 0.0f, 0.0f, 0.0f, 0.0f,  0.0f,  0.0f, -1.0f, 1.0f,
                          0.5f,  0.0f,  0.0f,  0.0f, 0.0f, 1.0f, -1.0f, -0.6f, 1.0f, 0.0f,  0.0f,
                          0.0f,  0.0f,  0.0f,  1.0f, 0.0f, 0.5f, 1.0f,  0.0f,  0.0f, 0.0f};

    unsigned int floorIndices[] = {0, 2, 1, 1, 2, 3};

    GLfloat floorVertices[] = {-1000.0f, 0.0f, -100.0f, 0.0f,    0.0f,   0.0f, -1.0f, 0.0f,
                               1000.0f,  0.0f, -100.0f, 1000.0f, 0.0f,   0.0f, -1.0f, 0.0f,
                               -1000.0f, 0.0f, 100.0f,  0.0f,    10.0f,  0.0f, -1.0f, 0.0f,
                               1000.0f,  0.0f, 100.0f,  1000.0f, 100.0f, 0.0f, -1.0f, 0.0f};

    calcAverageNormals(indices, 12, vertices, 32, 8, 5);

    ObjMesh *obj1 = new ObjMesh();
    obj1->CreateObjMesh(vertices, indices, 32, 12);
    meshList.push_back(obj1);

    ObjMesh *obj2 = new ObjMesh();
    obj2->CreateObjMesh(vertices, indices, 32, 12);
    meshList.push_back(obj2);

    ObjMesh *obj3 = new ObjMesh();
    obj3->CreateObjMesh(floorVertices, floorIndices, 32, 6);
    meshList.push_back(obj3);
}

void SceneBasic_Uniform ::render() {
    DirectionalShadowMapPass(&mainLight);
    for (size_t i = 0; i < pointLightCount; i++) {
        SpecialShadowMapPass(&pointLights[i]);
    }

    RenderPass(projection, camera.calculateViewMatrix());

    glUseProgram(0);
}

void SceneBasic_Uniform ::resize(int w, int h) {
    width = w;
    height = h;
    glViewport(0, 0, w, h);
}
void SceneBasic_Uniform ::keyCallback(int key, int scancode, int action, int mods) 
{
    if (key >= 0 && key < 1024) {
        if (action == GLFW_PRESS) {
            keys[key] = true;
        } else if (action == GLFW_RELEASE) {
            keys[key] = false;
        }
    }
}
void SceneBasic_Uniform ::mouseMoveCallback(double xPos, double yPos) {
    if (mouseFirstMoved) {
        lastX = static_cast<GLfloat>(xPos);
        lastY = static_cast<GLfloat>(yPos);
        mouseFirstMoved = false;
    }
    xChange = static_cast<GLfloat>(xPos) - lastX;
    yChange = lastY - static_cast<GLfloat>(yPos);

    lastX = static_cast<GLfloat>(xPos);
    lastY = static_cast<GLfloat>(yPos);
}