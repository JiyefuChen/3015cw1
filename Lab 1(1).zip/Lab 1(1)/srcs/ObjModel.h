#pragma once

#include <vector>
#include <string>

#include "ObjModel.h"
#include "Texture.h"

class ObjMesh
{
public:
	ObjMesh();

	void CreateObjMesh(GLfloat* vertices, unsigned int* indices, unsigned int numOfVertices, unsigned int numOfIndices);
	void RenderObjMesh();
	void ClearObjMesh();

	~ObjMesh();

private:
    GLuint VAO, VBO, IBO = 0;
    GLsizei indexCount;
};

class ObjMaterial
{
public:
	ObjMaterial();
	ObjMaterial(GLfloat sIntensity, GLfloat shine);

	void UseObjMaterial(GLuint specularIntensityLocation, GLuint shininessLocation);

	~ObjMaterial();

private:
	GLfloat specularIntensity;
	GLfloat shininess;
};

class ObjModel
{
public:
	ObjModel();

	void LoadObjModel(const std::string& fileName);
	void LoadObjModelCar(const std::string& fileName);
	void LoadObjModelLightControl1(const std::string& fileName);
	void LoadObjModelLightControl2(const std::string& fileName);
	
	void RenderObjModel();
	void ClearObjModel();

	~ObjModel();

private:

	void _LoadObjModel(const std::string& fileName);

	// void LoadObjMaterials(const aiScene *scene);
	// void LoadObjMaterialsCar(const aiScene* scene);
	// void LoadObjMaterialsLightControl1(const aiScene* scene);
	// void LoadObjMaterialsLightControl2(const aiScene* scene);
		
	std::vector<ObjMesh*> meshList;
	std::vector<Texture*> textureList;
	std::vector<unsigned int> meshToTex;
};

