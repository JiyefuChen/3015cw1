#include "ObjModel.h"
#include <filesystem>

#define TINYOBJLOADER_IMPLEMENTATION
#include <iostream>

#include "helper/tiny_obj_loader.h"

ObjMesh::ObjMesh() {
    VAO = 0;
    VBO = 0;
    IBO = 0;
    indexCount = 0;
}

void ObjMesh::CreateObjMesh(GLfloat* vertices, unsigned int* indices, unsigned int numOfVertices,
                            unsigned int numOfIndices) {
    indexCount = numOfVertices;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    if (indices) {
        indexCount = numOfIndices;
        glGenBuffers(1, &IBO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * numOfIndices, indices, GL_STATIC_DRAW);
    }

    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * numOfVertices, vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]) * 8, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(vertices[0]) * 8, (void*)(sizeof(vertices[0]) * 3));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(vertices[0]) * 8, (void*)(sizeof(vertices[0]) * 5));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
}

void ObjMesh::RenderObjMesh() {
    glBindVertexArray(VAO);
    if (IBO) {
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0);
    } else
        glDrawArrays(GL_TRIANGLES, 0, indexCount);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void ObjMesh::ClearObjMesh() {
    if (IBO != 0) {
        glDeleteBuffers(1, &IBO);
        IBO = 0;
    }

    if (VBO != 0) {
        glDeleteBuffers(1, &VBO);
        VBO = 0;
    }

    if (VAO != 0) {
        glDeleteVertexArrays(1, &VAO);
        VAO = 0;
    }

    indexCount = 0;
}

ObjMesh::~ObjMesh() { ClearObjMesh(); }

ObjMaterial::ObjMaterial() {
    specularIntensity = 0.0f;
    shininess = 0.0f;
}

ObjMaterial::ObjMaterial(GLfloat sIntensity, GLfloat shine) {
    specularIntensity = sIntensity;
    shininess = shine;
}

void ObjMaterial::UseObjMaterial(GLuint specularIntensityLocation, GLuint shininessLocation) {
    glUniform1f(specularIntensityLocation, specularIntensity);
    glUniform1f(shininessLocation, shininess);
}

ObjMaterial::~ObjMaterial() {}

ObjModel::ObjModel() {}

void ObjModel::RenderObjModel() {
    for (size_t i = 0; i < meshList.size(); i++) {
        unsigned int materialIndex = meshToTex[i];

        if (materialIndex < textureList.size() && textureList[materialIndex]) {
            textureList[materialIndex]->UseTexture();
        }

        meshList[i]->RenderObjMesh();
    }
}
void ObjModel::LoadObjModel(const std::string& fileName){
    _LoadObjModel(fileName);
    for (auto&& e : textureList)
    {
        if (!e) {
            e = new Texture("media/Textures/plain.png");
            e->LoadTextureA();
        }
    }
}
void ObjModel::LoadObjModelCar(const std::string& fileName){
    _LoadObjModel(fileName);

    for (auto&& e : textureList)
    {
        if (!e) {
            e = new Texture("media/Textures/blue.png");
            e->LoadTextureA();
        }
    }
}
void ObjModel::LoadObjModelLightControl1(const std::string& fileName){
    _LoadObjModel(fileName);
    for (auto&& e : textureList)
    {
        if (!e) {
            e = new Texture("media/Textures/blue.png");
            e->LoadTextureA();
        }
    }
}
void ObjModel::LoadObjModelLightControl2(const std::string& fileName){
    _LoadObjModel(fileName);
    for (auto&& e : textureList)
    {
        if (!e) {
            e = new Texture("media/Textures/red.png");
            e->LoadTextureA();
        }
    }
}

void ObjModel::_LoadObjModel(const std::string& inputfile) {
    auto path=std::filesystem::path(inputfile);
    

    tinyobj::ObjReaderConfig reader_config;
    reader_config.mtl_search_path = path.parent_path().string();;  // Path to material files
    reader_config.triangulate = true;

    tinyobj::ObjReader reader;

    if (!reader.ParseFromFile(inputfile.c_str(), reader_config)) {
        if (!reader.Error().empty()) {
            std::cerr << "TinyObjReader: " << reader.Error();
        }
        exit(1);
    }

    if (!reader.Warning().empty()) {
        std::cout << "TinyObjReader: " << reader.Warning();
    }

    auto& attrib = reader.GetAttrib();
    auto& shapes = reader.GetShapes();
    auto& materials = reader.GetMaterials();

    auto materialCount = materials.size();
    textureList.resize(materialCount);
    for (size_t i = 0; i < materialCount; ++i) {
        auto&& m = materials[i];
        if (!m.diffuse_texname.empty()) {
            auto str = reader_config.mtl_search_path + "/" + m.diffuse_texname;
            textureList[i] = new Texture(str.c_str());
            if (!textureList[i]->LoadTexture()) {
                printf("Failed to load texture at: %s\n", m.diffuse_texname.c_str());
                delete textureList[i];
                textureList[i] = nullptr;
            }
        }
    }
    textureList.emplace_back();

    // Loop over shapes
    for (size_t s = 0; s < shapes.size(); s++) {
        // Loop over faces(polygon)
        ObjMesh* newObjMesh = new ObjMesh();
        meshToTex.emplace_back(UINT32_MAX);
        std::vector<GLfloat> vertices;
        std::vector<unsigned int> indices;
        size_t index_offset = 0;
        for (size_t f = 0; f < shapes[s].mesh.num_face_vertices.size(); f++) {
            size_t fv = size_t(shapes[s].mesh.num_face_vertices[f]);

            // Loop over vertices in the face.
            for (size_t v = 0; v < fv; v++) {
                // access to vertex
                tinyobj::index_t idx = shapes[s].mesh.indices[index_offset + v];
                tinyobj::real_t vx = attrib.vertices[3 * size_t(idx.vertex_index) + 0];
                tinyobj::real_t vy = attrib.vertices[3 * size_t(idx.vertex_index) + 1];
                tinyobj::real_t vz = attrib.vertices[3 * size_t(idx.vertex_index) + 2];

                vertices.emplace_back(vx);
                vertices.emplace_back(vy);
                vertices.emplace_back(vz);

                // Check if `texcoord_index` is zero or positive. negative = no texcoord data
                if (idx.texcoord_index >= 0) {
                    tinyobj::real_t tx = attrib.texcoords[2 * size_t(idx.texcoord_index) + 0];
                    tinyobj::real_t ty = attrib.texcoords[2 * size_t(idx.texcoord_index) + 1];
                    vertices.emplace_back(tx);
                    vertices.emplace_back(1. - ty);
                } else {
                    vertices.emplace_back(0);
                    vertices.emplace_back(0);
                }

                // Check if `normal_index` is zero or positive. negative = no normal data
                if (idx.normal_index >= 0) {
                    tinyobj::real_t nx = attrib.normals[3 * size_t(idx.normal_index) + 0];
                    tinyobj::real_t ny = attrib.normals[3 * size_t(idx.normal_index) + 1];
                    tinyobj::real_t nz = attrib.normals[3 * size_t(idx.normal_index) + 2];
                    vertices.emplace_back(-nx);
                    vertices.emplace_back(-ny);
                    vertices.emplace_back(-nz);
                }

                // Optional: vertex colors
                // tinyobj::real_t red   = attrib.colors[3*size_t(idx.vertex_index)+0];
                // tinyobj::real_t green = attrib.colors[3*size_t(idx.vertex_index)+1];
                // tinyobj::real_t blue  = attrib.colors[3*size_t(idx.vertex_index)+2];
            }
            index_offset += fv;

            // per-face material
            // shapes[s].mesh.material_ids[f];
        }
        if (shapes[s].mesh.material_ids[0] == -1)
            meshToTex[s] = textureList.size() - 1;
        else
            meshToTex[s] = shapes[s].mesh.material_ids[0];
        newObjMesh->CreateObjMesh(vertices.data(), 0, vertices.size(), 0);
        meshList.emplace_back(newObjMesh);
    }
}

// void ObjModel::LoadObjModelCar(const std::string& fileName)
// {
// 	Assimp::Importer importer;
// 	const aiScene* scene = importer.ReadFile(fileName, aiProcess_Triangulate | aiProcess_FlipUVs |
// aiProcess_GenSmoothNormals | aiProcess_JoinIdenticalVertices);

// 	if (!scene)
// 	{
// 		printf("ObjModel (%s) failed to load: %s", fileName.c_str(), importer.GetErrorString());
// 		return;
// 	}

// 	LoadNode(scene->mRootNode, scene);

// 	LoadObjMaterialsCar(scene);
// }

// void ObjModel::LoadObjModelLightControl1(const std::string& fileName)
// {
// 	Assimp::Importer importer;
// 	const aiScene* scene = importer.ReadFile(fileName, aiProcess_Triangulate | aiProcess_FlipUVs |
// aiProcess_GenSmoothNormals | aiProcess_JoinIdenticalVertices);

// 	if (!scene)
// 	{
// 		printf("ObjModel (%s) failed to load: %s", fileName.c_str(), importer.GetErrorString());
// 		return;
// 	}

// 	LoadNode(scene->mRootNode, scene);

// 	LoadObjMaterialsLightControl1(scene);
// }

// void ObjModel::LoadObjModelLightControl2(const std::string& fileName)
// {
// 	Assimp::Importer importer;
// 	const aiScene* scene = importer.ReadFile(fileName, aiProcess_Triangulate | aiProcess_FlipUVs |
// aiProcess_GenSmoothNormals | aiProcess_JoinIdenticalVertices);

// 	if (!scene)
// 	{
// 		printf("ObjModel (%s) failed to load: %s", fileName.c_str(), importer.GetErrorString());
// 		return;
// 	}

// 	LoadNode(scene->mRootNode, scene);

// 	LoadObjMaterialsLightControl2(scene);
// }

// void ObjModel::LoadNode(aiNode * node, const aiScene * scene)
// {
// 	for (size_t i = 0; i < node->mNumMeshes; i++)
// 	{
// 		LoadObjMesh(scene->mMeshes[node->mMeshes[i]], scene);
// 	}

// 	for (size_t i = 0; i < node->mNumChildren; i++)
// 	{
// 		LoadNode(node->mChildren[i], scene);
// 	}
// }

// void ObjModel::LoadObjMesh(aiMesh * mesh, const aiScene * scene)
// {
// 	std::vector<GLfloat> vertices;
// 	std::vector<unsigned int> indices;

// 	for (size_t i = 0; i < mesh->mNumVertices; i++)
// 	{
// 		vertices.insert(vertices.end(), { mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z });
// 		if (mesh->mTextureCoords[0])
// 		{
// 			vertices.insert(vertices.end(), { mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y });
// 		}
// 		else {
// 			vertices.insert(vertices.end(), { 0.0f, 0.0f });
// 		}
// 		vertices.insert(vertices.end(), { -mesh->mNormals[i].x, -mesh->mNormals[i].y, -mesh->mNormals[i].z });
// 	}

// 	for (size_t i = 0; i < mesh->mNumFaces; i++)
// 	{
// 		aiFace face = mesh->mFaces[i];
// 		for (size_t j = 0; j < face.mNumIndices; j++)
// 		{
// 			indices.push_back(face.mIndices[j]);
// 		}
// 	}

// 	ObjMesh* newObjMesh = new ObjMesh();
// 	newObjMesh->CreateObjMesh(&vertices[0], &indices[0], vertices.size(), indices.size());
// 	meshList.push_back(newObjMesh);
// 	meshToTex.push_back(mesh->mMaterialIndex);
// }

// void ObjModel::LoadObjMaterials(const aiScene * scene)
// {
// 	textureList.resize(scene->mNumMaterials);

// 	for (size_t i = 0; i < scene->mNumMaterials; i++)
// 	{
// 		aiMaterial* material = scene->mMaterials[i];

// 		textureList[i] = nullptr;

// 		if (material->GetTextureCount(aiTextureType_DIFFUSE))
// 		{
// 			aiString path;
// 			if (material->GetTexture(aiTextureType_DIFFUSE, 0, &path) == AI_SUCCESS)
// 			{
// 				int idx = std::string(path.data).rfind("\\");
// 				std::string filename = std::string(path.data).substr(idx + 1);

// 				std::string texPath = std::string("media/Textures/") + filename;

// 				textureList[i] = new Texture(texPath.c_str());

// 				if (!textureList[i]->LoadTexture())
// 				{
// 					printf("Failed to load texture at: %s\n", texPath.c_str());
// 					delete textureList[i];
// 					textureList[i] = nullptr;
// 				}
// 			}
// 		}

// 		if (!textureList[i])
// 		{
// 			textureList[i] = new Texture("media/Textures/plain.png");
// 			textureList[i]->LoadTextureA();

// 			//textureList[i] = new Texture("Textures/YellowBlack.jpg");
// 			//textureList[i]->LoadTexture();
// 		}
// 	}
// }

// void ObjModel::LoadObjMaterialsCar(const aiScene* scene)
// {
// 	textureList.resize(scene->mNumMaterials);

// 	for (size_t i = 0; i < scene->mNumMaterials; i++)
// 	{
// 		aiMaterial* material = scene->mMaterials[i];

// 		textureList[i] = nullptr;

// 		if (material->GetTextureCount(aiTextureType_DIFFUSE))
// 		{
// 			aiString path;
// 			if (material->GetTexture(aiTextureType_DIFFUSE, 0, &path) == AI_SUCCESS)
// 			{
// 				int idx = std::string(path.data).rfind("\\");
// 				std::string filename = std::string(path.data).substr(idx + 1);

// 				std::string texPath = std::string("media/Textures/") + filename;

// 				textureList[i] = new Texture(texPath.c_str());

// 				if (!textureList[i]->LoadTexture())
// 				{
// 					printf("Failed to load texture at: %s\n", texPath.c_str());
// 					delete textureList[i];
// 					textureList[i] = nullptr;
// 				}
// 			}
// 		}

// 		if (!textureList[i])
// 		{
// 			//textureList[i] = new Texture("Textures/plain.png");
// 			//textureList[i]->LoadTextureA();

// 			textureList[i] = new Texture("media/Textures/blue.png");
// 			textureList[i]->LoadTextureA();
// 		}
// 	}
// }

// void ObjModel::LoadObjMaterialsLightControl1(const aiScene* scene)
// {
// 	textureList.resize(scene->mNumMaterials);

// 	for (size_t i = 0; i < scene->mNumMaterials; i++)
// 	{
// 		aiMaterial* material = scene->mMaterials[i];

// 		textureList[i] = nullptr;

// 		if (material->GetTextureCount(aiTextureType_DIFFUSE))
// 		{
// 			aiString path;
// 			if (material->GetTexture(aiTextureType_DIFFUSE, 0, &path) == AI_SUCCESS)
// 			{
// 				int idx = std::string(path.data).rfind("\\");
// 				std::string filename = std::string(path.data).substr(idx + 1);

// 				std::string texPath = std::string("media/Textures/") + filename;

// 				textureList[i] = new Texture(texPath.c_str());

// 				if (!textureList[i]->LoadTexture())
// 				{
// 					printf("Failed to load texture at: %s\n", texPath.c_str());
// 					delete textureList[i];
// 					textureList[i] = nullptr;
// 				}
// 			}
// 		}

// 		if (!textureList[i])
// 		{
// 			//textureList[i] = new Texture("Textures/plain.png");
// 			//textureList[i]->LoadTextureA();

// 			textureList[i] = new Texture("media/Textures/blue.png");
// 			textureList[i]->LoadTexture();
// 		}
// 	}
// }

// void ObjModel::LoadObjMaterialsLightControl2(const aiScene* scene)
// {
// 	textureList.resize(scene->mNumMaterials);

// 	for (size_t i = 0; i < scene->mNumMaterials; i++)
// 	{
// 		aiMaterial* material = scene->mMaterials[i];

// 		textureList[i] = nullptr;

// 		if (material->GetTextureCount(aiTextureType_DIFFUSE))
// 		{
// 			aiString path;
// 			if (material->GetTexture(aiTextureType_DIFFUSE, 0, &path) == AI_SUCCESS)
// 			{
// 				int idx = std::string(path.data).rfind("\\");
// 				std::string filename = std::string(path.data).substr(idx + 1);

// 				std::string texPath = std::string("media/Textures/") + filename;

// 				textureList[i] = new Texture(texPath.c_str());

// 				if (!textureList[i]->LoadTexture())
// 				{
// 					printf("Failed to load texture at: %s\n", texPath.c_str());
// 					delete textureList[i];
// 					textureList[i] = nullptr;
// 				}
// 			}
// 		}

// 		if (!textureList[i])
// 		{
// 			//textureList[i] = new Texture("Textures/plain.png");
// 			//textureList[i]->LoadTextureA();

// 			textureList[i] = new Texture("media/Textures/red.png");
// 			textureList[i]->LoadTextureA();
// 		}
// 	}
// }

void ObjModel::ClearObjModel() {
    for (size_t i = 0; i < meshList.size(); i++) {
        if (meshList[i]) {
            delete meshList[i];
            meshList[i] = nullptr;
        }
    }

    for (size_t i = 0; i < textureList.size(); i++) {
        if (textureList[i]) {
            delete textureList[i];
            textureList[i] = nullptr;
        }
    }
}

ObjModel::~ObjModel() {}
