#pragma once

#include <glad/glad.h>

#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>
#include <string>
#include <vector>

#include "Common.h"
#include "ObjModel.h"
#include "helper/glslprogram.h"

class Skybox {
public:
    Skybox();

    Skybox(std::vector<std::string> faceLocations);

    void DrawSkybox(glm::mat4 viewMatrix, glm::mat4 projectionMatrix);

    ~Skybox();

private:
    ObjMesh* skyObjMesh;
    // Shader* skyShader;
    GLSLProgram* skyShader;

    GLuint textureId;
    GLuint uniformProjection, uniformView;
};
