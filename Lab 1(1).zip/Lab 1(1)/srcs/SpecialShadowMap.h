#pragma once
#include "ShadowMap.h"
class SpecialShadowMap :
	public ShadowMap
{
public:
	SpecialShadowMap();

	bool Init(unsigned int width, unsigned int height);

	void Write();

	void Read(GLenum TextureUnit);

	~SpecialShadowMap();
};

