#ifndef SCENEBASIC_UNIFORM_H
#define SCENEBASIC_UNIFORM_H

#include <glad/glad.h>

#include "ObjModel.h"
#include "Camera.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "Skybox.h"
#include "Texture.h"
#include "helper/glslprogram.h"
#include "helper/scene.h"

class SceneBasic_Uniform : public Scene {
private:
    std::vector<ObjMesh*> meshList;

    GLSLProgram defaultShader;
    GLSLProgram directionalShadowShader;
    GLSLProgram omniShadowShader;

    GLint uniformObjModel;

    Camera camera;

    Texture brickTexture;
    Texture dirtTexture;
    Texture plainTexture;

    ObjMaterial shinyObjMaterial;
    ObjMaterial dullObjMaterial;

    ObjModel xwing;
    ObjModel blackhawk;
    ObjModel lightControlBox1;
    ObjModel lightControlBox2;
    ObjModel pBlue;
    ObjModel pYellow;

    bool lightcontrolFlag1 = false;
    bool lightcontrolFlag2 = false;

    DirectionalLight mainLight;
    PointLight pointLights[MAX_POINT_LIGHTS];

    Skybox skybox;

    unsigned int pointLightCount = 0;

    GLfloat deltaTime = 0.0f;
    GLfloat lastTime = 0.0f;

    GLfloat blackhawkAngle = 0.0f;

    GLfloat carPosition = -0.99f;
    GLfloat carSpeed = 0.002f;
    GLfloat turnAngle = 90;
    bool movingForward = false;

    bool keys[1024];

    GLfloat lastX;
    GLfloat lastY;
    GLfloat xChange;
    GLfloat yChange;
    bool mouseFirstMoved;

    void compile();
    void calcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices,
                            unsigned int verticeCount, unsigned int vLength, unsigned int normalOffset);
    void CreateObjects();
    void RenderScene();
    void RenderPass(glm::mat4 projectionMatrix, glm::mat4 viewMatrix);
    void SpecialShadowMapPass(PointLight* light);
    void DirectionalShadowMapPass(DirectionalLight* light);

    void keyCallback(int key, int scancode, int action, int mods) override;
    void mouseMoveCallback(double xpos, double ypos) override;

public:
    SceneBasic_Uniform();

    void initScene();
    void update(float t);
    void render();
    void resize(int, int);
};

#endif  // SCENEBASIC_UNIFORM_H
